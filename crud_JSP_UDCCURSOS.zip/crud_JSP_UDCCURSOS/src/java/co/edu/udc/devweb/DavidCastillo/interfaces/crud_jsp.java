/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.udc.devweb.DavidCastillo.interfaces;

import java.util.List;
import co.edu.udc.devweb.DavidCastillo.modelo.cursos;

/**
 *
 * @author DC
 */
public interface crud_jsp {
    public List listar();
    public cursos list(int id);
    public boolean agregar (cursos cel);
    public boolean editar (cursos cel);
    public boolean eliminar (int id);
    
    


}
