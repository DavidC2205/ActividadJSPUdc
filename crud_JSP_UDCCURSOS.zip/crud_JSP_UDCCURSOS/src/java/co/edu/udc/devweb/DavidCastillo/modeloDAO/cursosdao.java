/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.udc.devweb.DavidCastillo.modeloDAO;

import co.edu.udc.devweb.actividad2.DavidCastillo.Configuracion.conexion;
import co.edu.udc.devweb.DavidCastillo.interfaces.crud_jsp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import co.edu.udc.devweb.DavidCastillo.modelo.cursos;

/**
 *
 * @author DC
 */
public class cursosdao implements crud_jsp {
    conexion cn=new conexion();
    Connection con;
     ResultSet rs;
    PreparedStatement ps;
   
    cursos cr=new cursos();
   
   @Override
   
   
   public List listar() {
       ArrayList<cursos>list=new ArrayList<>();
       String sql ="select * from cursos";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
                cursos cr   = new cursos();
            cr.setId(rs.getInt("id"));
            cr.setNombre(rs.getString("Nombre"));
            cr.setPrecio(rs.getDouble("Precio"));
            cr.setHoras(rs.getInt("Horas"));
            cr.setNivel(rs.getString("Nivel"));
            cr.setProfesor(rs.getString("Profesor"));
            cr.setInstitucion(rs.getString("Institucion"));
            cr.setFechaInscripcionI(rs.getDate("Fecha de Inscripcion"));
            cr.setFechaInscripcionF(rs.getDate("Fecha Final de Inscripcion"));
            cr.setFechainicio(rs.getDate("Fecha Inicio"));
            cr.setFechacierre(rs.getDate("Fecha Cierre"));
            cr.setNumAlum(rs.getInt("Numero de Alumnos"));
            cr.setModalidad(rs.getString("Modalidad"));
            cr.setDescripcion(rs.getString("Descripicion"));
                list.add(cr);
                
            
            }  
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public cursos list(int id) {
        String sql ="select * from cursos where id="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
              
            cr.setId(rs.getInt("id"));
            cr.setNombre(rs.getString("Nombre"));
             cr.setPrecio(rs.getDouble("Precio"));
            cr.setHoras(rs.getInt("Horas"));
            cr.setNivel(rs.getString("Nivel"));
            cr.setProfesor(rs.getString("Profesor"));
            cr.setInstitucion(rs.getString("Institucion"));
            cr.setFechaInscripcionI(rs.getDate("Fecha de Inscripcion"));
            cr.setFechaInscripcionF(rs.getDate("Fecha Final de Inscripcion"));
            cr.setFechainicio(rs.getDate("Fecha Inicio"));
            cr.setFechacierre(rs.getDate("Fecha Cierre"));
            cr.setNumAlum(rs.getInt("Numero de Alumnos"));
            cr.setModalidad(rs.getString("Modalidad"));
            cr.setDescripcion(rs.getString("Descripicion"));
            
                
            
            }  
        } catch (Exception e) {
        }
        return cr;
    }

    @Override
    public boolean agregar(cursos cur) {
        String sql ="insert into Cursos (nombre, precio, horas,nivel,profesor,institucion,FechaInscripcionI,FechaInscripcionF,FechaInicio,Fechacierre,NumAlum,Modalidad,Descripcion)values('"+ cur.getNombre()+"','"+cur.getPrecio()+"','"+cur.getHoras()+"','"+cur.getNivel()+"','"+cur.getProfesor()+"','"+cur.getInstitucion()+"','"+cur.getFechaInscripcionI()+"','"+cur.getFechaInscripcionF()+"','"+cur.getFechainicio()+"','"+cur.getFechacierre()+"','"+cur.getNumAlum()+"','"+cur.getModalidad()+"','"+cur.getDescripcion()+"')";
        try {
           con=cn.getConnection();
           ps=con.prepareStatement(sql);
           ps.executeUpdate();
        } catch (Exception e) {
        }
        
        
        return false;
    }

    @Override
    public boolean editar(cursos cur) {
               String sql ="update Cursos set nombre='"+cur.getNombre()+"',horas='"+cur.getHoras()+"',nivel='"+cur.getNivel()+"',profesor='"+cur.getProfesor()+"',institucion='"+cur.getInstitucion()+"',FechaInscripcionI='"+cur.getFechaInscripcionI()+"',FechaInscripcionF='"+cur.getFechaInscripcionF()+"',FechaInicio='"+cur.getFechainicio()+"',FechaCierre='"+cur.getFechacierre()+"',Numero de Alumnos='"+cur.getNumAlum()+"',Modalidad='"+cur.getModalidad()+"',Descripcion='"+cur.getDescripcion()+"'where id="+cur.getId();
               try {
            con=cn.getConnection();
           ps=con.prepareStatement(sql);
           ps.executeUpdate();
        } catch (Exception e) {
            
        }
               return false;
               
               
    }

    @Override
    public boolean eliminar(int id) {
       String sql ="delete from Cursos where id="+id;
        try {
              con=cn.getConnection();
           ps=con.prepareStatement(sql);
           ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }
    
    
    
}
