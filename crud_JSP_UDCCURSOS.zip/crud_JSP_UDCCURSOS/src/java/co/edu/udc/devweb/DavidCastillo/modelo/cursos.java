/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.udc.devweb.DavidCastillo.modelo;

import java.util.Date;

/**
 *
 * @author DC
 */
public class cursos
{
    int id;
    String nombre;
    double precio;
     int horas;
    String nivel;
    String profesor;
    String institucion;
     java.util.Date fechaInscripcionI ;
   java.util.Date fechaInscripcionF ;
    java.util.Date fechainicio;
    java.util.Date  fechacierre;
    int numAlum;
    String Modalidad;
    String Descripcion;

    public cursos(int id, String nombre, double precio, int horas, String nivel, String profesor, String institucion, Date fechaInscripcionI, Date fechaInscripcionF, Date fechainicio, Date fechacierre, int numAlum, String Modalidad, String Descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.horas = horas;
        this.nivel = nivel;
        this.profesor = profesor;
        this.institucion = institucion;
        this.fechaInscripcionI = fechaInscripcionI;
        this.fechaInscripcionF = fechaInscripcionF;
        this.fechainicio = fechainicio;
        this.fechacierre = fechacierre;
        this.numAlum = numAlum;
        this.Modalidad = Modalidad;
        this.Descripcion = Descripcion;
    }
    
    public cursos() {
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public String getInstitucion() {
        return institucion;
    }

    public void setInstitucion(String institucion) {
        this.institucion = institucion;
    }

    public Date getFechaInscripcionI() {
        return fechaInscripcionI;
    }

    public void setFechaInscripcionI(Date fechaInscripcionI) {
        this.fechaInscripcionI = fechaInscripcionI;
    }

    public Date getFechaInscripcionF() {
        return fechaInscripcionF;
    }

    public void setFechaInscripcionF(Date fechaInscripcionF) {
        this.fechaInscripcionF = fechaInscripcionF;
    }

    public Date getFechainicio() {
        return fechainicio;
    }

    public void setFechainicio(Date fechainicio) {
        this.fechainicio = fechainicio;
    }

    public Date getFechacierre() {
        return fechacierre;
    }

    public void setFechacierre(Date fechacierre) {
        this.fechacierre = fechacierre;
    }

    public int getNumAlum() {
        return numAlum;
    }

    public void setNumAlum(int numAlum) {
        this.numAlum = numAlum;
    }

    public String getModalidad() {
        return Modalidad;
    }

    public void setModalidad(String Modalidad) {
        this.Modalidad = Modalidad;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public String getProfesor() {
        return profesor;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

 
    
    
}
